<?php $__env->startSection('title', 'Tambah Kategori Produk'); ?>

<?php $__env->startSection('content'); ?>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <form action="/produk/insertkategori" method="POST">
            <?php echo csrf_field(); ?>
      <!-- Info boxes -->
            <div class="row">
                <div class="col-sm-6">
                    <div class="card py-3 px-3">
                        <div class="row">
                            <div class="col-sm-6">
                                <!-- select -->
                                <div class="form-group">
                                <label>Nama Kategori</label>
                                <input type="text" name="nama_kategori" placeholder="Nama Kategori" class="form-control">
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <!-- select -->
                                <div class="form-group">
                                <label>Status Kategori</label>
                                <select class="form-control" name="status">
                                    <option value="1">Aktif</option>
                                    <option value="0">Tidak Aktif</option>
                                </select>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <button type="submit" class="form-control btn btn-primary">Simpan</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6">
                    <div class="card py-3 px-3">
                        <div class="row">
                            <div class="col-sm-12">
                                <h2 class="text-center">List Kategori</h2>
                            </div>

                            <div class="col-sm-12">
                                    <table id="example2" class="table table-bordered table-hover text-center" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Nama Kategori</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                        <td><?php echo e($k->id); ?></td>
                                        <td><?php echo e($k->nama_kategori); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <script>
        $(function () {
            $("#example1").DataTable({
            "responsive": true,
            "autoWidth": false,
            });
            $('#example2').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": true,
            "ordering": true,
            "info": true,
            "autoWidth": true,
            "responsive": true,
            });
        });
    </script>

  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\sigavapps\resources\views/produk/kategori.blade.php ENDPATH**/ ?>