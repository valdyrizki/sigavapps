<?php $__env->startSection('title', 'Tambah Produk'); ?>

<?php $__env->startSection('content'); ?>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="card py-3 px-3">
            <form action="/produk/insert" method="POST">
                <?php echo csrf_field(); ?>
        <!-- Info boxes -->
                <div class="row">
                    <div class="col-sm-3">
                        <!-- select -->
                        <div class="form-group">
                        <label>Nama Produk</label>
                        <input type="text" name="nama_produk" placeholder="Nama Produk" class="form-control">
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <!-- select -->
                        <div class="form-group">
                        <label>Kategori</label>
                        <select class="form-control" name="id_kategori">
                            <option selected disabled>--- Pilih Kategori ---</option>
                            <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($k->id); ?>"><?php echo e($k->id); ?> - <?php echo e($k->nama_kategori); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                        </div>
                    </div>

                    <div class="col-sm-3">
                        <div class="form-group">
                            <label>Distributor</label>
                            <input type="text" class="form-control" name="distributor" placeholder="URL atau Nama Distributor">
                        </div>
                    </div>

                    <div class="col-sm-3">
                        <div class="form-group">
                            <label>Stok</label>
                            <input type="text" class="form-control" name="stok" placeholder="Stok">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-3">
                        <div class="form-group">
                            <label>Harga Modal</label>
                            <input type="number" class="form-control" name="harga_modal" placeholder="Harga Modal">
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="form-group">
                            <label>Harga Jual</label>
                            <input type="number" class="form-control" name="harga_jual" placeholder="Harga Jual">
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="form-group">
                            <label>Diskon</label>
                            <input type="number" class="form-control" name="diskon" placeholder="Diskon dalam %">
                        </div>
                    </div>
                    <div class="col-sm-3">
                            <div class="form-group">
                                <label>Status</label>
                                <select class="form-control" name="status">
                                    <option value="1">Aktif</option>
                                    <option value="0">Tidak Aktif</option>
                                </select>
                            </div>
                        </div>
                </div>

                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label>Deskripsi</label>
                            <textarea class="form-control" name="deskripsi" placeholder="Deskripsi Produk"></textarea>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <button type="submit" class="form-control btn btn-primary">Simpan</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>


        <div class="card py-3 px-3">
            <div class="row">
                <div class="col-sm-12">
                    <h2 class="text-center">List Produk</h2>
                </div>
            </div>

            <div class="col-sm-12">
                    <table id="example2" class="table table-bordered table-hover text-center" style="width:100%">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nama</th>
                            <th>Kategori</th>
                            <th>Stok</th>
                            <th>Modal</th>
                            <th>Harga</th>
                            <th>Diskon</th>
                            <th>Distributor</th>
                            <th>Deskripsi</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($p->id); ?></td>
                            <td><?php echo e($p->nama_produk); ?></td>
                            <td><?php echo e($p->id_kategori); ?></td>
                            <td><?php echo e($p->stok); ?></td>
                            <td><?php echo e($p->harga_modal); ?></td>
                            <td><?php echo e($p->harga_jual); ?></td>
                            <td><?php echo e($p->diskon); ?></td>
                            <td><?php echo e($p->distributor); ?></td>
                            <td><?php echo e($p->deskripsi); ?></td>
                            <td><?php echo e($p->status); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        $(function () {
            $("#example1").DataTable({
            "responsive": true,
            "autoWidth": false,
            });
            $('#example2').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": true,
            "ordering": true,
            "info": true,
            "autoWidth": true,
            "responsive": true,
            });
        });
    </script>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\sigavapps\resources\views/produk/index.blade.php ENDPATH**/ ?>