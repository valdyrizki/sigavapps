<?php $__env->startSection('title', 'Tambah Produk'); ?>

<?php $__env->startSection('content'); ?>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <form action="/produk/insert" method="POST">
            <?php echo csrf_field(); ?>
      <!-- Info boxes -->
            <div class="row">
                <div class="col-sm-4">
                    <!-- select -->
                    <div class="form-group">
                    <label>Nama Produk</label>
                    <input type="text" name="nama_produk" placeholder="Nama Produk" class="form-control">
                    </div>
                </div>
                <div class="col-sm-4">
                    <!-- select -->
                    <div class="form-group">
                    <label>Kategori</label>
                    <select class="form-control" name="id_kategori">
                        <option selected disabled>--- Pilih Kategori ---</option>
                        <option>Tentang Kita</option>
                        <option>Kuota Indosat</option>
                        <option>Kuota Axis</option>
                        <option>Kuota Tsel</option>
                        <option>option 4</option>
                        <option>option 5</option>
                    </select>
                    </div>
                </div>

                <div class="col-sm-4">
                    <div class="form-group">
                        <label>Distributor</label>
                        <input type="text" class="form-control" name="distributor" placeholder="URL atau Nama Distributor">
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-4">
                    <div class="form-group">
                        <label>Harga Modal</label>
                        <input type="number" class="form-control" name="harga_modal" placeholder="Harga Modal">
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                        <label>Harga Jual</label>
                        <input type="number" class="form-control" name="harga_jual" placeholder="Harga Jual">
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                        <label>Diskon</label>
                        <input type="number" class="form-control" name="diskon" placeholder="Diskon dalam %">
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group">
                        <label>Deskripsi</label>
                        <textarea class="form-control" name="deskripsi" placeholder="Deskripsi Produk"></textarea>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group">
                        <button type="submit" class="form-control btn btn-primary">Simpan</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\sigavapps\resources\views/produk/add.blade.php ENDPATH**/ ?>